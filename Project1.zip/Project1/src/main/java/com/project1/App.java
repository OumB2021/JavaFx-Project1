package com.project1;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import java.io.IOException;


public class App extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage PS) throws IOException {

        try{
            Canvas canvas = new Canvas(1000, 1000);
            GraphicsContext graphicContext = canvas.getGraphicsContext2D();      
            Pane P = new Pane();
            P.getChildren().add(canvas);
            Scene newScene = new Scene(P, Color.CORNSILK);
            PS.setTitle("Project3");
            PS.setScene(newScene);

            //Objects
            MyPoint p = new MyPoint(650, 500, MyColor.RED);
            //String filename = JOptionPane.showInputDialog("Enter the name of the File:");
            String filename = "War_and_Peace.txt";
            HistogramAlphaBet histogram = new HistogramAlphaBet(filename);
            HistogramAlphaBet.MyPieChart pie = histogram.new MyPieChart(0, p, 300, 0);
            pie.draw(graphicContext);
            PS.show();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }   
}